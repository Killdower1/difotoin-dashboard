'use client';

import { useEffect, useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useRouter } from 'next/navigation';

type Row = {
  id: number;
  category: string;
  min_foto_per_day: number;
  min_unlock_pct: number;
  min_print_pct: number;
  updated_at: string;
};

export default function ThresholdsPage() {
  const router = useRouter();
  const [rows, setRows] = useState<Row[]>([]);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ category: '', min_foto_per_day: '0', min_unlock_pct: '0', min_print_pct: '0' });

  useEffect(() => {
    fetch('/api/thresholds', { cache: 'no-store' })
      .then(r => r.json())
      .then(d => setRows(d.data || []))
      .catch(() => {});
  }, []);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter(r => r.category.toLowerCase().includes(s));
  }, [rows, q]);

  function resetForm() {
    setForm({ category: '', min_foto_per_day: '0', min_unlock_pct: '0', min_print_pct: '0' });
  }

  async function save() {
    const payload = {
      category: form.category,
      min_foto_per_day: Number(form.min_foto_per_day),
      min_unlock_pct: Number(form.min_unlock_pct),
      min_print_pct: Number(form.min_print_pct),
    };
    const res = await fetch('/api/thresholds', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      setOpen(false);
      resetForm();
      router.refresh();
      const fresh = await fetch('/api/thresholds', { cache: 'no-store' }).then(r => r.json());
      setRows(fresh.data || []);
    }
  }

  async function remove(category: string) {
    const res = await fetch('/api/thresholds/' + encodeURIComponent(category), { method: 'DELETE' });
    if (res.ok) {
      setRows(prev => prev.filter(p => p.category !== category));
    }
  }

  function edit(r: Row) {
    setForm({
      category: r.category,
      min_foto_per_day: String(r.min_foto_per_day),
      min_unlock_pct: String(r.min_unlock_pct),
      min_print_pct: String(r.min_print_pct),
    });
    setOpen(true);
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Thresholds (Foto / Unlock / Print)</h1>
        <div className="flex gap-2">
          <Input placeholder="Cari kategori..." value={q} onChange={e => setQ(e.target.value)} className="w-56" />
          <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetForm(); }}>
            <DialogTrigger asChild>
              <Button onClick={() => setOpen(true)}>Tambah / Edit</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[520px]">
              <DialogHeader>
                <DialogTitle>{form.category ? 'Edit' : 'Tambah'} Threshold</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <Input
                  placeholder="Category keeper"
                  value={form.category}
                  onChange={e => setForm(s => ({ ...s, category: e.target.value }))}
                />
                <Input
                  placeholder="Min Foto / Hari"
                  type="number"
                  value={form.min_foto_per_day}
                  onChange={e => setForm(s => ({ ...s, min_foto_per_day: e.target.value }))}
                />
                <Input
                  placeholder="Min Unlock %"
                  type="number"
                  value={form.min_unlock_pct}
                  onChange={e => setForm(s => ({ ...s, min_unlock_pct: e.target.value }))}
                />
                <Input
                  placeholder="Min Print %"
                  type="number"
                  value={form.min_print_pct}
                  onChange={e => setForm(s => ({ ...s, min_print_pct: e.target.value }))}
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setOpen(false)}>Batal</Button>
                <Button onClick={save}>Simpan</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Category</TableHead>
            <TableHead className="text-right">Min Foto/Hari</TableHead>
            <TableHead className="text-right">Min Unlock %</TableHead>
            <TableHead className="text-right">Min Print %</TableHead>
            <TableHead>Diperbarui</TableHead>
            <TableHead className="text-right">Aksi</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filtered.map(r => (
            <TableRow key={r.category}>
              <TableCell className="font-medium">{r.category}</TableCell>
              <TableCell className="text-right">{r.min_foto_per_day}</TableCell>
              <TableCell className="text-right">{new Intl.NumberFormat('id-ID', { maximumFractionDigits: 2 }).format(r.min_unlock_pct)}</TableCell>
              <TableCell className="text-right">{new Intl.NumberFormat('id-ID', { maximumFractionDigits: 2 }).format(r.min_print_pct)}</TableCell>
              <TableCell>{new Date(r.updated_at).toLocaleString('id-ID')}</TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end gap-2">
                  <Button size="sm" variant="outline" onClick={() => edit(r)}>Edit</Button>
                  <Button size="sm" variant="destructive" onClick={() => remove(r.category)}>Hapus</Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
          {filtered.length === 0 && (
            <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground">Belum ada data.</TableCell></TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
