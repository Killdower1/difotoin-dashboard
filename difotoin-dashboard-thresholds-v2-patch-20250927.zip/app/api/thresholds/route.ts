import { NextResponse } from 'next/server';
import { listThresholds, upsertThreshold } from '@/lib/server/thresholds';
import { requireAdmin } from '@/lib/server/auth';

export async function GET() {
  await requireAdmin();
  const rows = listThresholds();
  return NextResponse.json({ data: rows });
}

export async function POST(req: Request) {
  await requireAdmin();
  const body = await req.json();
  const { category, min_foto_per_day, min_unlock_pct, min_print_pct } = body || {};
  if (!category || String(category).trim() === '') {
    return NextResponse.json({ error: 'category wajib' }, { status: 400 });
  }
  const nFoto = Number(min_foto_per_day);
  const nUnlock = Number(min_unlock_pct);
  const nPrint = Number(min_print_pct);
  if ([nFoto, nUnlock, nPrint].some(n => Number.isNaN(n))) {
    return NextResponse.json({ error: 'angka tidak valid' }, { status: 400 });
  }
  upsertThreshold({
    category: String(category).trim(),
    min_foto_per_day: Math.max(0, Math.floor(nFoto)),
    min_unlock_pct: Math.max(0, nUnlock),
    min_print_pct: Math.max(0, nPrint),
  });
  return NextResponse.json({ ok: true });
}
