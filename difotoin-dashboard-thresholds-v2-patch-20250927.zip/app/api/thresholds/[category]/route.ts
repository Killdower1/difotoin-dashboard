import { NextResponse } from 'next/server';
import { removeThreshold } from '@/lib/server/thresholds';
import { requireAdmin } from '@/lib/server/auth';

export async function DELETE(_req: Request, { params }: { params: { category: string } }) {
  await requireAdmin();
  const category = decodeURIComponent(params.category);
  removeThreshold(category);
  return NextResponse.json({ ok: true });
}
