import { NextResponse } from 'next/server';
import db from '@/lib/server/db';
import { evaluateDailyStats } from '@/lib/server/keeper';
import { requireAuth } from '@/lib/server/auth';

export async function GET() {
  await requireAuth();
  // Sesuaikan nama tabel field sesuai skema kamu
  const rows = db.prepare(`
    SELECT o.id as outlet_id, o.name, o.area, o.category_keeper,
           COALESCE(s.foto,0)   as foto,
           COALESCE(s.unlock,0) as unlock,
           COALESCE(s.print,0)  as print,
           o.last_seen_at
    FROM outlets o
    LEFT JOIN stats_daily s
      ON s.outlet_id = o.id AND s.date = date('now','localtime')
    ORDER BY o.name ASC
  `).all();

  const data = rows.map((r: any) => {
    const ev = evaluateDailyStats({
      foto: r.foto, unlock: r.unlock, print: r.print, category: r.category_keeper
    });
    return {
      outlet_id: r.outlet_id,
      name: r.name,
      area: r.area,
      category_keeper: r.category_keeper,
      last_seen_at: r.last_seen_at,
      foto: r.foto, unlock: r.unlock, print: r.print,
      eval: { status: ev.status, fails: ev.fails, unlock_rate: ev.unlock_rate, print_rate: ev.print_rate }
    };
  });

  return NextResponse.json({ data });
}
