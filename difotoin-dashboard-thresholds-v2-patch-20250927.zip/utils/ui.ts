export function statusClass(s: 'OK'|'WARN'|'BAD') {
  if (s === 'OK') return 'ring-1 ring-emerald-400/50';
  if (s === 'WARN') return 'ring-1 ring-amber-400/50';
  return 'ring-1 ring-rose-500/60';
}
