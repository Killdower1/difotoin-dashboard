PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS thresholds_v2 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL UNIQUE,
  min_foto_per_day INTEGER NOT NULL DEFAULT 0,
  min_unlock_pct   REAL    NOT NULL DEFAULT 0,
  min_print_pct    REAL    NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL DEFAULT (datetime('now','localtime'))
);

INSERT OR IGNORE INTO thresholds_v2 (category, min_foto_per_day, min_unlock_pct, min_print_pct) VALUES
('Default', 30, 35.0, 60.0),
('Mall-Premium', 60, 40.0, 65.0),
('Mall-Standar', 40, 35.0, 60.0),
('Outdoor-Event', 80, 30.0, 55.0);
