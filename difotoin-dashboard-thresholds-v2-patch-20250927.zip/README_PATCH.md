# difotoin-dashboard — Thresholds v2 Patch (Foto / Unlock / Print)

## Isi patch
- `sql/2025-09-27_thresholds_v2.sql` — tabel & seed thresholds_v2
- `lib/server/thresholds.ts` — repo thresholds
- `lib/server/keeper.ts` — evaluator status OK/WARN/BAD
- `app/api/thresholds/route.ts` — API list + upsert
- `app/api/thresholds/[category]/route.ts` — API delete
- `app/api/outlets/today/route.ts` — API data dashboard berisi eval
- `app/admin/thresholds/page.tsx` — halaman admin thresholds
- `utils/ui.ts` — helper warna status

> Catatan: Sesuaikan nama tabel `outlets`, `stats_daily`, dan field `last_seen_at` dengan skema yang ada pada project kamu (jika berbeda).

## Cara apply (Git)
```bash
# 1) Buat branch baru
git checkout -b feature/thresholds-v2

# 2) Copy isi patch ke root repo
#    (kalau kamu download ZIP patch, ekstrak lalu timpa folder di repo)
#    Pastikan struktur path sama persis.

# 3) Apply SQL ke SQLite (WIB)
sqlite3 data.db < sql/2025-09-27_thresholds_v2.sql

# 4) Commit
git add sql lib app utils
git commit -m "feat(thresholds): v2 foto/unlock/print + admin panel"

# 5) Push
git push -u origin feature/thresholds-v2
```

## Endpoint baru
- `GET /api/thresholds` (admin)
- `POST /api/thresholds` (admin) — body: { category, min_foto_per_day, min_unlock_pct, min_print_pct }
- `DELETE /api/thresholds/[category]` (admin)
- `GET /api/outlets/today` (auth)

## Halaman baru
- `/admin/thresholds` (admin only)

## Integrasi di dashboard
- Konsumsi `/api/outlets/today` untuk dapatkan:
  ```json
  {
    "outlet_id": "xxx",
    "name": "Outlet A",
    "area": "Jakarta",
    "category_keeper": "Mall-Standar",
    "last_seen_at": "2025-09-27 12:34:00",
    "foto": 120,
    "unlock": 50,
    "print": 30,
    "eval": {
      "status": "WARN",
      "fails": ["UNLOCK"],
      "unlock_rate": 41.67,
      "print_rate": 60.00
    }
  }
  ```
- Gunakan helper `statusClass(status)` untuk ring/badge warna kartu.

## Anti-bug hydration
- Untuk angka: format di server & client dengan `Intl.NumberFormat('id-ID')` agar konsisten.
- Theme toggle: pastikan state ada & toggle class `dark` di `<html>`.

## Rollback
- Hapus file-file patch ini, lalu:
```bash
git checkout .
git clean -fd
git checkout main
git branch -D feature/thresholds-v2
```
