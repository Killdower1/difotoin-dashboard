import db from './db';

export type ThresholdRow = {
  id: number;
  category: string;
  min_foto_per_day: number;
  min_unlock_pct: number;
  min_print_pct: number;
  updated_at: string;
};

export function listThresholds(): ThresholdRow[] {
  return db.prepare(`SELECT * FROM thresholds_v2 ORDER BY category ASC`).all();
}

export function getThreshold(category: string): ThresholdRow | undefined {
  return db.prepare(`SELECT * FROM thresholds_v2 WHERE category = ?`).get(category);
}

export function upsertThreshold(payload: {
  category: string;
  min_foto_per_day: number;
  min_unlock_pct: number;
  min_print_pct: number;
}) {
  const stmt = db.prepare(`
    INSERT INTO thresholds_v2 (category, min_foto_per_day, min_unlock_pct, min_print_pct, updated_at)
    VALUES (@category, @min_foto_per_day, @min_unlock_pct, @min_print_pct, datetime('now','localtime'))
    ON CONFLICT(category) DO UPDATE SET
      min_foto_per_day = excluded.min_foto_per_day,
      min_unlock_pct   = excluded.min_unlock_pct,
      min_print_pct    = excluded.min_print_pct,
      updated_at       = datetime('now','localtime')
  `);
  stmt.run(payload);
}

export function removeThreshold(category: string) {
  db.prepare(`DELETE FROM thresholds_v2 WHERE category = ?`).run(category);
}
