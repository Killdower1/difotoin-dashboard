import db from './db';

export type KeeperEval = {
  status: 'OK' | 'WARN' | 'BAD';
  fails: Array<'FOTO'|'UNLOCK'|'PRINT'>;
  unlock_rate: number; // 0..100
  print_rate: number;  // 0..100
  min_foto_per_day: number;
  min_unlock_pct: number;
  min_print_pct: number;
};

export function getThresholdForCategory(category?: string) {
  const row = category
    ? db.prepare(`SELECT * FROM thresholds_v2 WHERE category = ?`).get(category)
    : undefined;
  const fallback = db.prepare(`SELECT * FROM thresholds_v2 WHERE category = 'Default'`).get();
  return row || fallback || { min_foto_per_day: 0, min_unlock_pct: 0, min_print_pct: 0 };
}

export function evaluateDailyStats(stats: { foto: number; unlock: number; print: number; category?: string }): KeeperEval {
  const t = getThresholdForCategory(stats.category);
  const unlock_rate = stats.foto > 0 ? (stats.unlock / stats.foto) * 100 : 0;
  const print_rate  = stats.unlock > 0 ? (stats.print  / stats.unlock) * 100 : 0;

  const fails: KeeperEval['fails'] = [];
  if (stats.foto   < t.min_foto_per_day) fails.push('FOTO');
  if (unlock_rate  < t.min_unlock_pct)   fails.push('UNLOCK');
  if (print_rate   < t.min_print_pct)    fails.push('PRINT');

  let status: KeeperEval['status'] = 'OK';
  if (fails.length === 1) status = 'WARN';
  if (fails.length >= 2)  status = 'BAD';

  return {
    status, fails,
    unlock_rate: Math.round(unlock_rate * 100) / 100,
    print_rate:  Math.round(print_rate * 100) / 100,
    min_foto_per_day: t.min_foto_per_day ?? 0,
    min_unlock_pct: t.min_unlock_pct ?? 0,
    min_print_pct: t.min_print_pct ?? 0,
  };
}
