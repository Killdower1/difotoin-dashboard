﻿export default { reactStrictMode: true };
